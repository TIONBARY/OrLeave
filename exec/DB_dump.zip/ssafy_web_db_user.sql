-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7a502.p.ssafy.io    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `birth_day` date NOT NULL,
  `drink` int(10) unsigned NOT NULL,
  `email` varchar(80) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `image_no` int(10) unsigned NOT NULL,
  `mbti` varchar(4) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `pw` varchar(255) NOT NULL,
  `religion` int(10) unsigned NOT NULL,
  `smoke` int(10) unsigned NOT NULL,
  `user_type` varchar(16) NOT NULL,
  PRIMARY KEY (`no`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`),
  UNIQUE KEY `UK_n4swgcf30j6bmtb4l4cjryuym` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'2000-10-01',0,'2@2','F',6,'ESFP','ㅇㅇ','$2a$10$CazphPXL1bjB143fixz5yuVIkA/MQn19L1Q1SwtFqLLbZc6nTWMiu',0,0,'USER'),(3,'1996-10-30',0,'dddalang4@naver.com','M',5,'ISTJ','판다','$2a$10$rDvHadOr.tzfqehwkB7dIukuGefQv1DVXhkHPpXbYDpswUGMwoZgG',0,0,'MANAGER'),(4,'1997-02-22',1,'azure_12@naver.com','F',8,'INTP','리밍구','$2a$10$BZ0TE3mT/pmcerZFBd0aGOo78sbdvbkSbZzrOBqbRx8ljTpMxkUhi',0,1,'USER'),(5,'2002-01-01',0,'lisajieun@naver.com','F',2,'ISFJ','수리수리','$2a$10$zuG0REfN8slmdRenVIjUOetCTJCsE9Ly/4kE67OnSWHg7cpYlJzbi',0,0,'USER'),(6,'1995-03-14',2,'wonch30@gmail.com','M',3,'ESTJ','Chan','$2a$10$H7iglAxaiOCn/AKVULx8/OeyWuIv5cyPlpaIYZh2ruvqbdGImcJqa',0,0,'USER'),(7,'1997-11-09',1,'qkftkftnf@naver.com','M',14,'ISFP','상수','$2a$10$TWx7gfguduE00/HpqbBAMulRaT3Ht9uta6xmksQWSsPJkDu808GES',0,0,'USER'),(8,'1992-01-09',2,'chwon03@naver.com','M',19,'ESFP','안녕하세요','$2a$10$zT4SpmIw2mZuK74nbB2DH.wsxey85ogBRbCw2V5XkD9ZODbrWEibq',1,1,'USER'),(9,'1999-11-11',1,'showegg@naver.com','M',20,'INFP','어머','$2a$10$vCVhsVXMWvElCIysSRZwuOlyAEOsiiZgjWxcSYxIYTe8bpscoDw7y',0,0,'USER'),(10,'1996-10-30',0,'dddalang3@gmail.com','F',5,'ENFJ','여판다','$2a$10$URuICfEDkHRLlVgb.qBP1OP1sFsPVqLyqRp3knIh8GT8Ujyj.hWka',0,0,'USER'),(11,'2000-01-01',2,'tmddnrdl333@naver.com','M',22,'ESFJ','스','$2a$10$.UN.wGnAsHBItocEFepJ6eiiaoPGTKSIMlY6rwtyrBRw93PkKwuHC',1,1,'USER'),(12,'1997-01-08',0,'daijang35@kakao.com','M',4,'ISFJ','허상','$2a$10$D0NcOrlbEGNcHxK/nWzZ9eMcQ1EENnaGlK91SC6TwQ09i9L6uKN2O',0,0,'MANAGER'),(13,'1994-06-13',1,'rlatldjs123@gmail.com','F',15,'ENFP','하나','$2a$10$DrLA4MI21jEdp4cWoyIv2e7vRDBuYMsNqPEKDl3jaGWgCXO3KdGX2',1,1,'USER'),(14,'1997-11-09',1,'holly0314@naver.com','F',20,'ISFP','박상수','$2a$10$d.RB/xajfTh.hyfLqD3yjueUshifgelrcNAGyeQkFhEUA0L7Xm0v2',0,0,'USER'),(15,'2002-01-02',2,'nohod39265@ukgent.com','M',1,'INTP','aaaaa','$2a$10$2.Mkaf/3UUH/dGq1FC9zye5xpXnnhs0EEU7VaJPniS8Yjsu4lc5Q6',0,0,'USER'),(16,'1997-08-13',1,'lakelop792@wnpop.com','M',7,'ESFP','응애다른반','$2a$10$FVEnB.qQ0YL/j6VZ0SS4/uAsvQK43fxdlOh0GCnILiIDyM2mAznjK',4,0,'USER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 10:06:23
